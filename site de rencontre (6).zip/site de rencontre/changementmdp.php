<?php
session_start(); // Ensure session is started

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the new password is provided
    if(isset($_POST["newpassword"]) && !empty($_POST["newpassword"])) {
        $newpassword = $_POST["newpassword"];

        // Open the data file for reading and writing
        $fichier = "donnees.txt";
        $handle = fopen($fichier, "r+");

        if ($handle) {
            while (!feof($handle)) {
                
                $pseudo = trim(fgets($handle));
                $position = ftell($handle);
                $mdp = trim(fgets($handle));
                
                // Check if the current password matches
                if ($_SESSION["password"] === $mdp) {
                    // Move file pointer to the beginning of the password line
                    fseek($handle, $position);
                    // Write the new password to the file
                    fwrite($handle, $newpassword . PHP_EOL);
                    fclose($handle);
                    // Update the session password
                    $_SESSION["password"] = $newpassword;
                    // Redirect to the homepage
                    header("Location: acceuil.php");
                    exit();
                } else {
                    // Move file pointer to the beginning of the next user's data
                    fseek($handle, $position + strlen($pseudo) + strlen($mdp) + 2); // Adding 2 for newline characters
                }
            }
            fclose($handle);
            echo "Mot de passe ou identifiant incorrect";
        } else {
            echo "Erreur lors de l'ouverture du fichier";
        }
    } else {
        echo "Le nouveau mot de passe n'a pas été fourni";
    }
}


$tab = array('a'=>4,6,8,'d'=>1,'e'=>1,'6'=>3);
    $count = 1;
    $value = "error";
    if(isset($tab[$count])){
        $value = $tab[0];
    }
    echo $value;

    echo "\n";
    echo "\n";
    function cytech($input){
        $data = explode('-',$input);
        $data2 = array();
        foreach($data as $k => $d){
            $d = strtolower($d);
            $d[0] = strtoupper($d[0]); // Convertit la première lettre en majuscule
            echo ("$k\n");
            echo ("$d\n");
            $data2[] =  $d;
        }
        $result = implode(',',$data2);
        return $result;
    }
    
    $msg = "oNE;tWO;tHREE-Four-five-six";
    $res = cytech($msg);
    echo $res; // Affiche "One,Two-three-four-five-six"
    
