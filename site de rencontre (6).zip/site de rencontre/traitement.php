<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération des champs du formulaire
    $pseudo = $_POST["pseudo"];
    $password = $_POST["password"];
    $nom = $_POST["nom"];
    $sexe = $_POST["sexe"];
    $date_naissance = $_POST["date"];
    $city = $_POST["city"];
    $poids = $_POST["poids"];
    $taille = $_POST["taille"];
    $sport = $_POST["sport"];
    $sports_pratiques = $_POST["sports_pratiques"];
    $description = $_POST["description"];
    $adresse = $_POST["adresse"]; // Adresse complète
    
    // Récupération et traitement de l'image
    if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == UPLOAD_ERR_OK) {
        $photo_name = $_FILES["photo"]["name"];
        
        // Déplacement de la photo téléchargée vers le dossier de destination
        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $photo_name)){
            // Ouverture du fichier texte en mode ajout
            $fichier = "donnees.txt";
            $handle = fopen($fichier, "a");
            if ($handle) {
                // Écriture des données dans le fichier texte
                if (filesize($fichier) > 0) {
                    // Si le fichier n'est pas vide, on ajoute deux sauts de ligne
                    fwrite($handle, PHP_EOL . PHP_EOL);
                }
                fwrite($handle,$pseudo . PHP_EOL);
                fwrite($handle,$password . PHP_EOL);
                fwrite($handle,$nom . PHP_EOL);
                fwrite($handle,$sexe . PHP_EOL);
                fwrite($handle,$date_naissance . PHP_EOL);
                fwrite($handle,$city . PHP_EOL);
                fwrite($handle,$poids . PHP_EOL);
                fwrite($handle,$taille . PHP_EOL);
                fwrite($handle, $sport. PHP_EOL);
                fwrite($handle,$sports_pratiques . PHP_EOL);
                fwrite($handle,$description . PHP_EOL);
                fwrite($handle,$adresse . PHP_EOL);
                fwrite($handle,$photo_name . PHP_EOL);
                fwrite($handle, date("Y-m-d"));
                fwrite($handle, PHP_EOL);
                fclose($handle);
                echo "Les données ont été enregistrées avec succès. <a href='connexion.html'>Retour à la page d'accueil</a>";
            } else {
                echo "Erreur lors de l'ouverture du fichier.";
            }
        } else {
            echo "Erreur lors du téléchargement de la photo.";
        }
    } else {
        echo "Veuillez sélectionner une photo.";
    }
}
?>
