
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mesmessage.css">
    <title>Document</title>
</head>
<body>

<div class="center-content">
<?php 

session_start();

$dossier = "messages/";

// Liste des fichiers dans le dossier
$fichiers = scandir($dossier);

$fichiersTexte = array();

foreach ($fichiers as $fichier) {
    
    if (strpos($fichier, $_SESSION['pseudo']) !== false){
        $parties = explode('_', $fichier);
        echo "<form action=message.php>";
        if($parties[0]== $_SESSION['pseudo']){
            $id = $parties[1];
        echo '<input type="hidden" name="id" value="<?php echo $id; ?>">';
        }else{
            $id = $parties[0];
        echo '<input type="hidden" name="id" value="<?php echo $id; ?>">';
        }
        echo "<div class='discussion-item'>";
echo "<div class='discussion-item-text'>$id</div>";
echo "<div class='discussion-item-button'>";
echo "<button> ✉️ </button>";
echo "</form></div>";
echo "</div>";

    }
}

?>
</div>
</body>
</html>

