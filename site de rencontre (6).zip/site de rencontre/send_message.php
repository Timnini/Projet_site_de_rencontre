<?php

session_start();

// Vérifier si un message est soumis
if (isset($_POST["message"]) && !empty($_POST["message"])) {
    // Ajouter le message au fichier texte
    $nom_fichier = $_SESSION['nom_fichier'];
    $file = fopen("messages/$nom_fichier", "a");
    fwrite($file, "|" . $_POST["message"] . "\n");
    fclose($file);
}


// Vérifier si la variable POST 'idmessupp' est définie
if( $_POST['idmessupp'] != false) {
    // Récupérer l'identifiant de la ligne à supprimer
    $lineId = $_POST['idmessupp'];

    // Chemin du fichier de messages
    $nom_fichier = $_SESSION['nom_fichier'];
    $fichierMessages = "messages/$nom_fichier";

    // Lire le contenu du fichier dans un tableau
    $contenu = file_get_contents($fichierMessages);

    // Diviser le contenu en messages individuels
    $messages = explode("|", $contenu);

    if(isset($messages[$lineId])) {
        unset($messages[$lineId]);

        // Réécrire le contenu du fichier avec les messages mis à jour
        $nouveauContenu = implode("|", $messages);
        file_put_contents($fichierMessages, $nouveauContenu);
    }
}



header("Location:message.php")
?>

