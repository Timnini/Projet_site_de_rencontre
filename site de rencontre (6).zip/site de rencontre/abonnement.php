<?php

session_start();

$_SESSION["abonnement"] = true;
header("refresh:1;url=profil.php");

?>