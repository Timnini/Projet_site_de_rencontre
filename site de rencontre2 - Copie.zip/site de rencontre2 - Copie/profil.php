<?php

session_start();

if (!isset($_SESSION['pseudo'])) {
    header("Location: connexion.php"); // Redirige vers la page de connexion si l'utilisateur n'est pas connecté
    exit();
}

$pseudo = $_SESSION['pseudo'];
$fichier = "donnees.txt";
$handle = fopen($fichier, "r");

if ($handle) {
    while (!feof($handle)) {
        $donnee = fgets($handle);
        $tab = explode("_", $donnee);
        $id = $tab[0];
        
        if ($pseudo == $id) {
            // Identifiant et mot de passe trouvés, extrayez les informations associées
            $mdp = $tab[1];
            $nom = $tab[2];
            $sexe = $tab[3];
            $date_naissance = $tab[4];
            $city = $tab[5];
            $poids = $tab[6];
            $taille = $tab[7];
            $sport = $tab[8];
            $sports_pratiques = $tab[9];
            $description = $tab[10];
            $adresse = $tab[11];
            $image = $tab[12];
            $date_inscription = $tab[13];
            $abonnement = $tab[14];
            if ($abonnement == 1) {
                $i = 15;
                $pseudo_visite = array();
                while (isset($tab[$i])) {
                    array_push($pseudo_visite,$tab[$i]);
                    $i++;
                }
            }
        } else {
            // Passer à l'entrée utilisateur suivant
            fgets($handle);
        }
    }
    fclose($handle);
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="profil.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap">
    <title>Profil</title>
</head>
<body>      
   
<div class="banner">
    <h1><a href="acceuil.php">SportMeet </a></h1>
    <p><em> Slogan </em></p>
    <button onclick="window.location.href='abonnements.html'">Abonnements</button>
</div>

<div id="page">
<h1 id="profil"><u>Profil</u></h1>
<h2>Informations personnelles :</h2>

<img src="<?php echo $image; ?>" alt="pas" width="100" height="100"/>

<?php if ($abonnement >= 1) { ?>
    <p> Abonné </p>
<?php } ?>

<p> Nom : <?php echo $nom; ?> </p>
<p> Pseudo : <?php echo $pseudo; ?></p>
<p> Mot de passe : <?php echo $mdp; ?>
<p> Date d'inscription : <?php echo $date_inscription; ?></p>
<p> Sexe : <?php echo $sexe; ?></p>
<p> Date de naissance : <?php echo $date_naissance; ?></p>
<p> Lieu de résidence : <?php echo $city; ?></p>
<p> Poids : <?php echo $poids; ?> kg</p>
<p> Taille : <?php echo $taille; ?> cm</p>
<p> Fréquence sport : <?php echo $sport; ?></p>
<p> Sport(s) pratiqué(s) : <?php echo $sports_pratiques; ?></p>
<p> Description : <?php echo $description; ?></p>

<?php if ($abonnement >= 1 && isset($pseudo_visite)) { ?>
    <div>Personnes ayant visité votre profil : <?php $pseudo_visite = implode(" ",$pseudo_visite);
         echo $pseudo_visite; ?></div>
<?php } ?>

<form action="modificationprofil.php" enctype="multipart/form-data" method="post" style="float:right"> 
    <br>
    <button type="submit"> Modifier </button>
</form>

<form action="mesmessages.php" enctype="multipart/form-data" method="post" style="float:left"> 
    <br>
    <button type="submit"> Mes messages </button>
</form>

<?php if ($abonnement == 2) { ?>
    <br>
    <button onclick="location.href='admin.html'"> Gestion Admin </button>
<?php } ?>

</div>
</body>
</html>
