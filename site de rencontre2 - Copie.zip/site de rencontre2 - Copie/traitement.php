<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération des champs du formulaire
    $pseudo = $_POST["pseudo"];
    $password = $_POST["password"];
    $nom = $_POST["nom"];
    $sexe = $_POST["sexe"];
    $date_naissance = $_POST["date"];
    $city = $_POST["city"];
    $poids = $_POST["poids"];
    $taille = $_POST["taille"];
    $sport = $_POST["sport"];
    $sports_pratiques = $_POST["sports_pratiques"];
    $description = $_POST["description"];
    $adresse = $_POST["adresse"]; // Adresse complète
    $abonnement = '0';
    
    // Récupération et traitement de l'image
    if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == UPLOAD_ERR_OK) {
        $photo_name = $_FILES["photo"]["name"];
        
        // Déplacement de la photo téléchargée vers le dossier de destination
        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $photo_name)){
            // Ouverture du fichier texte en mode ajout
            $date_inscription =  date("Y-m-d");
            $tab=array($pseudo,$password,$nom,$sexe,$date_naissance,$city,$poids,$taille,$sport,$sports_pratiques,$description,$adresse,$photo_name, $date_inscription,$abonnement);
            $tab2 = implode('_',$tab);
            $fichier = "donnees.txt";
            $handle = fopen($fichier, "a");
            if ($handle) {
            if(filesize($fichier) > 0){
                fwrite($handle,"\n");
            }
           fwrite($handle,$tab2);
                fclose($handle);
                echo "Les données ont été enregistrées avec succès. <a href='connexion.html'>Retour à la page d'accueil</a>";
            } else {
                echo "Erreur lors de l'ouverture du fichier.";
            }
        } else {
            echo "Erreur lors du téléchargement de la photo.";
        }
    } else {
        echo "Veuillez sélectionner une photo.";
    }
}
?>
