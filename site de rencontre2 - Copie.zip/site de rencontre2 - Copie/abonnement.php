<?php

session_start();


$fichier = "donnees.txt";
$handle = fopen($fichier, "r+");


if ($handle) {
    while (!feof($handle)) {
        $position = ftell($handle);
        $donnee = fgets($handle);
        $tab = explode("_",$donnee);
        $id = $tab[0];
        if ($_SESSION["pseudo"] == $id) {
            // Identifiant et mot de passe trouvés, extrayez les informations associées
            $tab[14] = "1";
            $tab = implode("_",$tab);
            fseek($handle, $position);
            fwrite($handle,$tab);}
            break; // Sortir de la boucle une fois que les informations sont trouvées
        }
    }
    fclose($handle);


header("refresh:1;url=profil.php");

?>