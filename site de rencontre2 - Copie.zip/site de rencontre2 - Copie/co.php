<?php

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {


    $pseudo = $_POST["pseudo"];
    $password = $_POST["password"];

    $fichier = "donnees.txt";
    $handle = fopen($fichier, "r");

    if ($handle) {
        while (!feof($handle)) { 
            $donnee = fgets($handle);
            $tab = explode("_",$donnee);
            $id = $tab[0];
            $mdp = $tab[1];
            if ($pseudo == $id && $password == $mdp) {
                fclose($handle);
                $_SESSION['connexion_pseudo'] = true;
                $_SESSION['pseudo'] = $pseudo;
                $_SESSION['password'] = $password; // Stocke le pseudo dans la session
                header("Location: acceuil.php"); // Redirige vers la page de profil
                exit();
            } else {
                    fgets($handle);
            }
        }
        fclose($handle);
        echo "Mot de passe ou identifiant incorrect";
    } else {
        echo "Erreur lors de l'ouverture du fichier";
    }
}
?>
