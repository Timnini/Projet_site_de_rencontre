<?php

session_start();

$pseudo = $_GET["id"];
if(isset($_SESSION["pseudo"])){
    $pseudovisiteur = $_SESSION["pseudo"];
}

$fichier = "donnees.txt";
$donnees = file($fichier, FILE_IGNORE_NEW_LINES); // Charger toutes les lignes dans un tableau

foreach ($donnees as $key => $donnee) {
    $tab = explode("_", $donnee);
    $id = $tab[0];
    if ($pseudo == $id) {
        // Identifiant trouvé, récupérez les informations de l'utilisateur
        $nom = $tab[2];
        $sexe = $tab[3];
        $date_naissance = $tab[4];
        $city = $tab[5];
        $poids = $tab[6];
        $taille = $tab[7];
        $sport = $tab[8];
        $sports_pratiques = $tab[9];
        $description = $tab[10];
        $adresse = $tab[11];
        $image = $tab[12];
        $date_inscription = $tab[13];
        $abonnement = $tab[14];

        // Mettez à jour la ligne avec les informations du visiteur
        $donnees[$key] .= "_" . $pseudovisiteur;
        break; // Sortez de la boucle une fois que la ligne est trouvée et mise à jour
    }
}

// Réécrivez le fichier avec les modifications
file_put_contents($fichier, implode("\n", $donnees));

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="profil.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap">
    <title>Profil</title>
</head>
<body>      
   
<div class="banner">
    <h1><a href="acceuil.php">SportMeet </a></h1>
    <p><em> Slogan </em></p>
</div>

<h1><u>Profil</u></h1>
<h2>Informations personnelles :</h2>

<img src="<?php echo $image; ?>" alt="pas" width="100" height="100"/>
<p> Pseudo : <?php echo $pseudo; ?></p>
<?php
if ($abonnement=='1') {
    echo "<p> Abonné </p>";
}
?>
<p> Date d'inscription : <?php echo $date_inscription; ?></p>
<p>Sexe : <?php echo $sexe; ?></p>
<p>Date de naissance : <?php echo $date_naissance; ?></p>
<p>Lieu de résidence : <?php echo $city; ?></p>
<p>Poids : <?php echo $poids; ?> kg</p>
<p>Taille : <?php echo $taille; ?> cm</p>
<p> fréquence sport : <?php echo $sport; ?></p>
<p>sport(s) pratiqué(s) : <?php echo $sports_pratiques; ?></p>
<p>description : <?php echo $description; ?></p>

<form action="message.php" method="post">
    <!-- Champ de formulaire caché pour stocker la valeur de $id -->
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    <!-- Bouton de soumission du formulaire -->

    <button type="submit">Message</button> 
</form>

</body>
</html>
