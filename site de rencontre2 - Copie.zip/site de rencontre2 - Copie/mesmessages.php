<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mesmessage.css">
    <title>Document</title>
</head>
<body>

<div class="banner">
        <div class="banner-text">Texte de la bannière</div>
        <button class="banner-button">Bouton de la bannière</button>
    </div>
    <div class="container">
        <!-- Contenu de votre page ici -->


<div class="center-content">
    
<?php 
session_start();

$dossier = "messages/";

// Liste des fichiers dans le dossier
$fichiers = scandir($dossier);

$fichiersTexte = array();

foreach ($fichiers as $fichier) {
    if ($fichier !== '.' && $fichier !== '..') {
        $parties = explode('_', $fichier);
        $partie1 = $parties[0];
        $partie2 = explode('.', $parties[1])[0];

        if ($partie1 == $_SESSION['pseudo']) {
            $id = $partie2;
        } elseif ($partie2 == $_SESSION['pseudo']) {
            $id = $partie1;
        } else {
            continue;
        }

        echo '<form action="message.php" method="post">';
        echo "<div class='discussion-item'>";
        echo "<div class='discussion-item-text'>";
        echo htmlspecialchars($id); // Utilisez htmlspecialchars pour sécuriser l'affichage des identifiants
        echo "</div>";
        echo "<div class='discussion-item-button'>";
        echo '<input type="hidden" name="id" value="' . htmlspecialchars($id) . '">';
        echo '<button type="submit"> ✉️ </button>';
        echo "</div></div></form>";
    }
}
?>

</div>
</div>

</body>
</html>
