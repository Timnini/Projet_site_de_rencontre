<?php

session_start();

$pseudo = $_POST["id"];

$fichier = "donnees.txt";
$donnees = file($fichier, FILE_IGNORE_NEW_LINES); // Charger toutes les lignes dans un tableau

foreach ($donnees as $key => $donnee) {
    $tab = explode("_", $donnee);
    $id = $tab[0];
    if ($pseudo == $id) {
        // Identifiant trouvé, récupérez les informations de l'utilisateur
        $mdp = $_POST["mdp"]; 
        $nom = $_POST["nom"];
        $sexe = $_POST["sexe"];
        $photo = $_POST["photo"];
        $date_naissance = $_POST["date_naissance"];
        $city = $_POST["city"];
        $poids = $_POST["poids"];
        $taille = $_POST["taille"];
        $sport = $_POST["sport"];
        $sports_pratiques = $_POST["sports_pratiques"];
        $description = $_POST["description"];
        $adresse = $_POST["adresse"];
        $date_inscription = $_POST["date_inscription"];
        $abonnement = $_POST["abonnement"];

        // Mettez à jour les données dans le tableau
        $donnees[$key] = $pseudo . "_" . $mdp . "_" . $nom . "_" . $sexe . "_" . $date_naissance . "_" . $city . "_" . $poids . "_" . $taille . "_" . $sport . "_" . $sports_pratiques . "_" . $description . "_" . $adresse . "_" . $photo . "_" . $date_inscription . "_" . $abonnement;

        break; // Sortez de la boucle une fois que la ligne est trouvée et mise à jour
    }
}

// Réécrivez le fichier avec les modifications
$result = file_put_contents($fichier, implode("\n", $donnees));

if ($result !== false) {
    echo "Les données ont été enregistrées avec succès. <a href='acceuil.php'>Retour à la page d'accueil</a>";
} else {
    echo "Erreur lors de l'enregistrement des données.";
}

?>
