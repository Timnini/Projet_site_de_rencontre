<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $pseudo = $_POST["pseudo"];
    $password = $_POST["password"];
    $sexe = $_POST["sexe"];
    $metier = $_POST["metier"];
    $city = $_POST["city"];
    $famille = $_POST["famille"];
    $amour = $_POST["amour"];
    $couleurCheveux = $_POST["Couleurcheveux"];
    $poids = $_POST["poids"];
    $taille = $_POST["taille"];
    $cheveux = $_POST["Cheveux"];
    $hobby = $_POST["hobby"];
    $fumeur = isset($_POST["fumeur"]) ? $_POST["fumeur"] : "non";
    $nonfumeur = isset($_POST["nonfumeur"]) ? $_POST["nonfumeur"] : "non";
    $photo = $_FILES["photo"]["tmp_name"];
    
    // Vérifier si une image a été téléchargée
    if ($photo) {
        $photo_data = file_get_contents($photo);
        $photo_base64 = base64_encode($photo_data);
    } else {
        $photo_base64 = ''; // Si aucune image n'a été téléchargée
    }
    

    $fichier = "donnees.txt";
    $handle = fopen($fichier, "a");

    if ($handle) {
        fwrite($handle,$pseudo . "\n");
        fwrite($handle,$password . "\n");
        fwrite($handle, $sexe ."\n");
        fwrite($handle, $metier ."\n");
        fwrite($handle, $city ."\n");
        fwrite($handle, $famille ."\n");
        fwrite($handle, $amour ."\n");
        fwrite($handle, $couleurCheveux ."\n");
        fwrite($handle, $poids ."\n");
        fwrite($handle, $taille ."\n");
        fwrite($handle, $cheveux . "\n");
        fwrite($handle, $hobby . "\n");
        if($fumeur== "fumeur"){
        fwrite($handle, $fumeur ."\n\n");}else
        {
        fwrite($handle, "non fumeur"."\n\n");}
        fclose($handle);
        echo "Les données ont été enregistrées avec succès. <a href='acceuil.php'>Retour à la page d'accueil</a>";
    } else {
        echo "Erreur lors de l'ouverture du fichier.";
    }
}
?>
