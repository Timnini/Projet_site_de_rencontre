<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="acceuil.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap">
    <title>Accueil</title>
</head>

<body>

<div class="banner">
<h1><a href="acceuil.php">SportMeet </a></h1>
    <p><em>Rencontrez l'âme sœur sur la piste de votre passion !</em></p>
    <div class="button-bandeau">
        <button onclick="window.location.href='connexion.html'">connexion</button>
    </div>
</div>

</body>
</html>
