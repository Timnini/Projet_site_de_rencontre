<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $password = $_POST["password"];
    $newpassword = $_POST["newpassword"];

    $fichier = "donnees.txt";
    $handle = fopen($fichier, "r+");

    if ($handle) {
        while (!feof($handle)) { 
           $pseudo = fgets($handle);
           $position = ftell($handle);
            $mdp = trim(fgets($handle)); 
            if ($password == $mdp){
                fseek($handle, $position);
                fwrite($handle,$newpassword);
                fclose($handle);
                header("Location: acceuil.php");
                exit();
            } else {
                for($i=0;$i<14;$i++){ // On passe à la prochaine entrée utilisateur
                    fgets($handle);
                }
            }
        }
        fclose($handle);
        echo "Mot de passe ou identifiant incorrect";
    } else {
        echo "Erreur lors de l'ouverture du fichier";
    }
}


?>