<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="acceuil.css">
    <link rel="stylesheet" href="acceuil2.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap">
    <title>Accueil</title>
</head>

<body>

<div class="banner">
<h1><a href="acceuil.php">SportMeet </a></h1>
    <p><em>Rencontrez l'âme sœur sur la piste de votre passion !</em></p>
</div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Bar with Filters</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="search-container">
    <form action="/search" method="get">
        <input type="text" placeholder="Search.." name="search">
        <br>
        <label for="nom">Prénom :</label>
    <input type="text" id="nom" name="nom" required><br>

    <label for="password">Mot de passe:</label>
    <input type="password" id="password" name="password" required><br>

    <label for="adresse">Adresse complète :</label>
    <input type="text" id="adresse" name="adresse" required><br>
    
    <h2>Profil :</h2>
    <label for="photo"> Photos </label>
    <input type="file" name="photo" accept="image/*" /><br>
    <label for="pseudo">Identifiant :</label>
    <input type="text" id="pseudo" name="pseudo" required><br>
    
    <label>Sexe :</label>
    <input type="radio" name="sexe" value="homme" required> Homme
    <input type="radio" name="sexe" value="femme"> Femme
    <input type="radio" name="sexe" value="autre"> Autre<br>
    
    <label>Date de naissance :</label>
    <input type="date" name="date" required><br>
    
    <label>Profession :</label>
    <input type="text" name="metier" required><br>
    
    <label>Lieu de résidence :</label>
    <select name="city" id="city">
        <option value="France">France</option>
        <option value="Autre">Autre</option>
    </select><br>
    
    <label>Situation familiale :</label>
    <input type="text" name="famille" required><br>
    
    <label>Situation amoureuse :</label>
    <input type="text" name="amour" required><br>
    
    <h2>Description physique :</h2>
    <label>Couleur des yeux :</label>
    <select name="Couleur yeux">
        <option value="bleu">Bleu</option>
        <option value="marron">Marron</option>
        <option value="vert">Vert</option>
        <option value="noir">Noir</option>
    </select><br>
    
    <label>Couleur des cheveux :</label>
    <select name="Couleurcheveux">
        <option value="blond">Blond</option>
        <option value="brun">Brun</option>
        <option value="noir">Noir</option>
        <option value="roux">Roux</option>
        <option value="autre">Autre</option>
    </select><br>
    
    <label>Type de cheveux :</label>
    <select name="Cheveux">
        <option value="lisse">Lisse</option>
        <option value="ondulé">Ondulé</option>
        <option value="bouclé">Bouclé</option>
    </select><br>
    
    <label>Poids (kg) :</label>
    <input type="number" name="poids" min="30" max="200" step="1"><br>
    
    <label>Taille (cm) :</label>
    <input type="number" name="taille" min="100" max="210" step="1"><br>
    
    <h2>Informations personnelles :</h2>
    <label>Sport(s) pratiqué(s) :</label>
    <input type="text" name="sport" required><br>
    
    <label>Autre(s) centre(s) d'intérêt(s) :</label>
    <input type="text" name="hobby" required><br>
    
    <label>Fumeur :</label>
    <input type="radio" name="fumeur" value="fumeur" required> Oui
    <input type="radio" name="fumeur" value="non-fumeur"> Non<br>
    
        <br>
        <button type="submit">Search</button>
    </form>
</div>

</body>
</html>


</body>
</html>
