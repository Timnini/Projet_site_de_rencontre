<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération des champs du formulaire
    $pseudo = str_replace('_', ' ', $_POST["pseudo"]);
    
    $banni = false;
    $fichier_banis = "../admin/banis.txt";
    $banis = file($fichier_banis, FILE_IGNORE_NEW_LINES);
    foreach ($banis as $pseudo_banni) {
        if ($pseudo_banni === $pseudo) {
            $banni = true;
            break;
        }
    }

    if (!$banni) {
        $password = str_replace('_', ' ', $_POST["password"]);
        $nom = str_replace('_', ' ', $_POST["nom"]);
        $sexe = str_replace('_', ' ', $_POST["sexe"]);
        $date_naissance = str_replace('_', ' ', $_POST["date"]);
        $city = str_replace('_', ' ', $_POST["city"]);
        $poids = str_replace('_', ' ', $_POST["poids"]);
        $taille = str_replace('_', ' ', $_POST["taille"]);
        $sport = str_replace('_', ' ', $_POST["sport"]);
        $sports_pratiques = str_replace('_', ' ', $_POST["sports_pratiques"]);
        $description = str_replace('_', ' ', $_POST["description"]);
        $adresse = str_replace('_', ' ', $_POST["adresse"]); // Adresse complète
        $abonnement = '0';
        $date_expiration = "000";

        // Récupération et traitement de l'image
        if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == UPLOAD_ERR_OK) {
            $photo_name = str_replace('_', ' ',"../uploads/" . basename($_FILES["photo"]["name"]));

            // Déplacement de la photo téléchargée vers le dossier de destination
            if (move_uploaded_file($_FILES["photo"]["tmp_name"], $photo_name)){
                // Ouverture du fichier texte en mode ajout
                $date_inscription = date("Y-m-d");
                $tab = array($pseudo, $password, $nom, $sexe, $date_naissance, $city, $poids, $taille, $sport, $sports_pratiques, $description, $adresse, $photo_name, $date_inscription, $abonnement, $date_expiration);
                $tab2 = implode('_', $tab);
                $fichier = "../donnees.txt";
                $handle = fopen($fichier, "a");
                if ($handle) {
                    if (filesize($fichier) > 0){
                        fwrite($handle, "\n");
                    }
                    fwrite($handle, $tab2);
                    fclose($handle);
                    echo "Les données ont été enregistrées avec succès. <a href='connexion.html'>Retour à la page d'accueil</a>";
                } else {
                    echo "Erreur lors de l'ouverture du fichier.";
                }
            } else {
                echo "Erreur lors du téléchargement de la photo.";
            }
        } else {
            echo "Veuillez sélectionner une photo.";
        }
    } else {
        echo "Vous êtes banni et ne pouvez pas vous inscrire.";
    }
}
?>
