<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="acceuil.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap">
    <title>Accueil</title>
</head>

<body>

<div class="banner">
    <h1><a href="acceuil.php">SportMeet</a></h1>
    <p><em>Rencontrez des partenaires pour des défis sportifs</em></p>
    <div class="button-bandeau">
        <?php
        session_start(); // Assurez-vous de démarrer la session avant d'utiliser $_SESSION

        if(isset($_SESSION['connexion_pseudo']) && $_SESSION['connexion_pseudo'] === true) {
            echo '<button onclick="recherche()"> 🔎 </button>';
            echo '<button id="buttonprofil" onclick="window.location.href=\'../utilisateur/profil.php\'">Profil</button>';
            echo '<button onclick="deconnexion()">Déconnexion</button>'; // Bouton de déconnexion
        } else {
            echo '<button onclick="window.location.href=\'connexion.html\'">Connexion</button>';
        }
        ?>

        <script>
            function recherche() {
                // Effectuez une requête AJAX ou redirigez simplement l'utilisateur vers une page de recherche
                window.location.href = '../utilisateur/recherche.php';
            }
            function deconnexion() {
                // Effectuez une requête AJAX ou redirigez simplement l'utilisateur vers une page de déconnexion
                window.location.href = '../utilisateur/deconnexion.php';
            }
        </script>
    </div>
</div>

<?php
// Fonction pour récupérer les informations d'un profil à partir du fichier de données
function recupererProfil($handle) {
    $donnee = fgets($handle);
    if ($donnee !== false) {
        $tab = explode("_", $donnee);
        $profil['id'] = $tab[0];
        $profil['sport_pratique'] = $tab[9];
        $profil['image'] = $tab[12];
        return $profil;
    } else {
        return null; // Retourne null si la fin du fichier est atteinte
    }
}
// Lire les utilisateurs bloqués
$fichier_bloque = "../utilisateur/utilisateurs_bloque.txt";
$utilisateurs_bloques = [];
if (file_exists($fichier_bloque)) {
    $lignes_bloquees = file($fichier_bloque, FILE_IGNORE_NEW_LINES);
    foreach ($lignes_bloquees as $ligne) {
        list($bloqueur, $bloque) = explode("_", $ligne);
        if (!isset($utilisateurs_bloques[$bloqueur])) {
            $utilisateurs_bloques[$bloqueur] = [];
        }
        $utilisateurs_bloques[$bloqueur][] = $bloque;
    }
}

// Ouvrir le fichier de données
$fichier = "../donnees.txt";
$handle = fopen($fichier, "r");

// Fonction pour afficher les informations d'un profil
function afficherProfil($profil, $utilisateurs_bloques, $pseudo_visiteur) {
    $est_bloque = isset($utilisateurs_bloques[$pseudo_visiteur]) && in_array($profil['id'], $utilisateurs_bloques[$pseudo_visiteur]);

    echo '<br>';
    echo '<table border="3" class="clickableTable" data-id="' . $profil['id'] . '" data-bloque="' . ($est_bloque ? '1' : '0') . '">';
   
    if ($est_bloque) {
        echo '<tr><td>Utilisateur bloqué</td></tr>';
    } 
    
   else {
    echo '<tr>';
    echo '<td><img src=" ../uploads/' . $profil['image'] . '" width="100" height="100"></td>';
    echo '</tr>';
    echo '<tr><td>id : ' . $profil['id'] . '</td></tr>';
        echo '<tr><td>Sport(s) pratiqué(s) : ' . $profil['sport_pratique'] . '</td></tr>';
    }
    echo '</table>';
}

// Récupérer et afficher les profils
$pseudo_visiteur = isset($_SESSION['pseudo']) ? $_SESSION['pseudo'] : null;
$profil1 = recupererProfil($handle);
if($profil1 !== null ){
afficherProfil($profil1, $utilisateurs_bloques, $pseudo_visiteur);}

$profil2 = recupererProfil($handle);
if($profil2 !== null ){
afficherProfil($profil2, $utilisateurs_bloques, $pseudo_visiteur);}

if (isset($_SESSION['connexion_pseudo']) && $_SESSION['connexion_pseudo'] === true) {
    $profil3 = recupererProfil($handle);
    if($profil3!== null){
    afficherProfil($profil3, $utilisateurs_bloques, $pseudo_visiteur);}

    $profil4 = recupererProfil($handle);
    if($profil4 !== null){
    afficherProfil($profil4, $utilisateurs_bloques, $pseudo_visiteur);}
} else {
    echo "<br><br>";
    echo '<button onclick="window.location.href=\'connexion.html\'">Voir plus</button>';
}

// Fermer le fichier de données
fclose($handle);

?>

<script>
    // Ajouter un gestionnaire d'événements pour rediriger vers le profil lors du clic sur la table
    var tables = document.querySelectorAll('.clickableTable');
    tables.forEach(function(table) {
        table.addEventListener('click', function() {
            var id = this.getAttribute('data-id');
            var bloque = this.getAttribute('data-bloque');
            if (bloque === '1') {
                alert("Utilisateur bloqué. Accès refusé.");
            } else {
                window.location.href = "../utilisateur/profil2.php?id=" + id;
            }
        });
    });
</script>

</body>
</html>
