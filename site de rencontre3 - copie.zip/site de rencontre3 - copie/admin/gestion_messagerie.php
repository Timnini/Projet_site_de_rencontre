<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../visiteur/acceuil.css">
    <title>Document</title>
</head>
<body> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .clickableTable {
            cursor: pointer;
            transition: transform 0.2s;
        }
        .clickableTable:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
<?php

$fichier = "../donnees.txt";
$handle = fopen($fichier, "r");

if ($handle) {
    // Lire chaque ligne du fichier et afficher le profil
    while (($donnee = fgets($handle)) !== false) {
        $profil = recupererProfil($donnee);
        afficherProfil($profil);
    }
    fclose($handle);
} else {
    echo "Erreur : impossible d'ouvrir le fichier.";
}

// Fonction pour récupérer les informations d'un profil à partir d'une ligne de données
function recupererProfil($donnee) {
    $tab = explode("_", trim($donnee));
    $profil = array();
    $profil['id'] = isset($tab[0]) ? $tab[0] : '';
    // Lire les autres informations nécessaires pour le profil
    $profil['sport_pratique'] = isset($tab[9]) ? $tab[9] : '';
    $profil['image'] = isset($tab[11]) ? $tab[12] : '';

    return $profil;
}

function afficherProfil($profil) {
    echo '<br>';
    echo '<table border="3" class="clickableTable">';
    echo '<tr>';
    echo '<td><img src="../uploads/' . $profil['image'] . '" width="100" height="100"></td>';
    echo '</tr>';
    echo '<tr><td>id : ' . $profil['id'] . '</td></tr>';
    echo '<tr><td>Sport(s) pratiqué(s) : ' . $profil['sport_pratique'] . '</td></tr>';
    echo '</table>';
} 

?>

<script>
    // Ajouter un gestionnaire d'événements pour rediriger vers le profil lors du clic sur la table
    var tables = document.querySelectorAll('.clickableTable');
    tables.forEach(function(table) {
        table.addEventListener('click', function() {
            var id = this.querySelector('tr:nth-child(2) td').innerText.split(':')[1].trim();
            window.location.href = "../abonnement/mesmessages2.php?id=" + id;
        });
    });
</script>
</body>
</html>


</body>
</html>