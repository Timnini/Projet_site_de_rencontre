<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pseudo = $_POST["pseudo"];
    $fichier = "../donnees.txt";
    $donnees = file($fichier, FILE_IGNORE_NEW_LINES); // Charger toutes les lignes dans un tableau
    $nouvelleDonnees = [];

    foreach ($donnees as $donnee) {
        $tab = explode("_", $donnee);
        $id = $tab[0];
        if ($pseudo != $id) {
            // Ajouter la ligne au tableau des nouvelles données si l'identifiant ne correspond pas
            $nouvelleDonnees[] = $donnee;
        }
    }

    // Réécrire le fichier avec les lignes restantes
    file_put_contents($fichier, implode("\n", $nouvelleDonnees));

    // Redirection après la suppression
    header("Location: admin.php");
    exit();
}
?>
