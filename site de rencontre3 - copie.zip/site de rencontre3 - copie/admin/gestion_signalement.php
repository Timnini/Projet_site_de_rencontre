<?php 

$contenu = file_get_contents("signalement.txt");
echo '</div>';

// Diviser le contenu en lignes
$messages = explode("|", $contenu);
$messageCounter = 1;

// Afficher chaque message sur une nouvelle ligne
foreach ($messages as $message) {
    echo "<br>";
    echo $message;
}

?>