<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="message.css">
    <title>Interface de messagerie</title>
    <style>
        /* Styles CSS précédents */
    </style>
</head>
<body>
    <div class="container">
        <ul class="messages">
        <?php
session_start();

// Vérifier si l'ID est transmis via GET
if(isset($_POST['id'])) {
    // Noms des participants
    $participant1 = $_POST['pseudo'];
    $_SESSION['participant2'] = $_POST['id'];
    $participant2 = $_SESSION['participant2'];

    // Nom du fichier de messages
    $nom_fichier = $participant1 . "_" . $participant2 . ".txt";

    // Chemin vers le dossier de stockage des fichiers de messages
    $dossier_messages = "../messages/";

    // Créer le fichier de messages s'il n'existe pas déjà
    if (file_exists($dossier_messages . $participant1 . "_" . $participant2 . ".txt")) {
        $_SESSION['nom_fichier'] = $participant1 . "_" . $participant2 . ".txt";
        echo "Le fichier de messages existe déjà : " . $_SESSION['nom_fichier'];
    } elseif (file_exists($dossier_messages . $participant2 . "_" . $participant1 . ".txt")) {
        $_SESSION['nom_fichier'] = $participant2 . "_" . $participant1 . ".txt";
        echo "Le fichier de messages existe déjà : " . $_SESSION['nom_fichier'];
    } else {
        $fichier = fopen($dossier_messages . $nom_fichier, "w");
        fclose($fichier);
        $_SESSION['nom_fichier'] = $nom_fichier;
        echo "Le fichier de messages a été créé avec succès : " . $nom_fichier;
    }
}
?>
        </ul>
        <div class="message">
            <form method="post" action="send_message.php">
                <br>
                <?php
                echo '<div id="nom">';
                echo $_SESSION['participant2'];
                echo '</div>';

                $nom_fichier = $_SESSION['nom_fichier'];
                $contenu = file_get_contents("../messages/$nom_fichier");

                if (!empty(trim($contenu))) {
                    // Diviser le contenu en lignes
                    $messages = explode("|", $contenu);

                    echo '<div class="cadre">';
                    // Afficher chaque message sur une nouvelle ligne
                    foreach ($messages as $message) {
                        echo "<br>";
                        echo $message;
                    }
                    echo '</div>';
                }
                ?>

                <br><br>
                <input type="text" name="message" placeholder="Entrez votre message...">
                <input type="hidden" name="id" value="<?php echo $participant2; ?>">
                <button type="submit">Envoyer</button>
                <br><br>
                <label> Ligne du message à supprimer <input type="number" name="idmessupp" min="1" max="200" step="1"> </label>
                <label> Ligne à Signaler <input type="number" name="ligne_signaler" min="1" max="200" step="1"> </label>
            </form>
        </div>
    </div>
</body>
</html>
