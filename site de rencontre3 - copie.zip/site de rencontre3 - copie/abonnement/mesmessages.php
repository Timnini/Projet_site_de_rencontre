<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mesmessage.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap">
    <title>SportMeet - Messages</title>
</head>
<body>

<div class="banner">
    <h1><a href="../visiteur/acceuil.php">SportMeet</a></h1>
    <p><em>Rencontrez vos partenaires d'entraînement et défiez vos limites ensemble !</em></p>
</div>

<div class="container">
    <div class="centered-element">

        <!-- Add some spacing -->
        <br><br><br><br><br><br>

        <?php 
        session_start();

        if (!isset($_SESSION['pseudo'])) {
            echo "Erreur : Pseudo non défini dans la session.";
            exit();
        }

        $pseudo = $_SESSION['pseudo'];
        $dossier = "../messages/";

        if (!is_dir($dossier)) {
            echo "Erreur : Le dossier de messages n'existe pas.";
            exit();
        }

        $fichiers = scandir($dossier);

        if ($fichiers === false) {
            echo "Erreur : Impossible de lire le dossier de messages.";
            exit();
        }

        foreach ($fichiers as $fichier) {
            if ($fichier !== '.' && $fichier !== '..') {
                $parties = explode('_', $fichier);
                $partie1 = $parties[0];
                $partie2 = explode('.', $parties[1])[0];

                if ($partie1 == $pseudo) {
                    $id = $partie2;
                } elseif ($partie2 == $pseudo) {
                    $id = $partie1;
                } else {
                    continue;
                }

                $image = "default.png";
                $fichierData = "../donnees.txt";

                if (file_exists($fichierData) && is_readable($fichierData)) {
                    $handle = fopen($fichierData, "r");

                    if ($handle) {
                        while (($line = fgets($handle)) !== false) {
                            $tab = explode("_", $line);
                            if (count($tab) > 12) { // Assurez-vous qu'il y a assez de colonnes
                                $id2 = $tab[0];
                                if ($id == $id2) {
                                    $image = trim($tab[12]);
                                    break;
                                }
                            }
                        }
                        fclose($handle);
                    }
                }

                $cheminImage = "../uploads/" . $image;
                if (!file_exists($cheminImage)) {
                    $cheminImage = "../uploads/default.png";
                }

                echo '<form action="message.php" method="post">';
                echo "<div class='discussion-item'>";
                echo "<div class='discussion-item-text'>";
                echo '<img src="' . htmlspecialchars($cheminImage) . '" width="50" height="50" style="border-radius: 50%; margin-left: 7%;">';
                echo htmlspecialchars($id);
                echo "</div>";
                echo "<div class='discussion-item-button'>";
                echo '<input type="hidden" name="id" value="' . htmlspecialchars($id) . '">';
                echo '<button type="submit">✉️</button>';
                echo "</div></div></form>";
                echo "<br>";
            }
        }
        ?>

    </div>
</div>

</body>
</html>
