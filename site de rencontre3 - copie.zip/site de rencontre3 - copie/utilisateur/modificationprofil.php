<?php
session_start();

if (!isset($_SESSION['pseudo'])) {
    header("Location: connexion.php"); // Redirige vers la page de connexion si l'utilisateur n'est pas connecté
    exit();
}

$pseudo = $_SESSION['pseudo'];

$fichier = "../donnees.txt";
$handle = fopen($fichier, "r");

$profilTrouve = false;

if ($handle) {
    while (!feof($handle)) {
        $donnee = fgets($handle);
        $donnee = trim($donnee); // Supprime les espaces autour de la ligne
        $tab = explode("_", $donnee);
        if (count($tab) >= 15) { // Assurez-vous qu'il y a suffisamment d'éléments dans la ligne
            $id = trim($tab[0]);
            if ($pseudo == $id) {
                // Identifiant trouvé, extrayez les informations associées
                $mdp = trim($tab[1]);
                $nom = trim($tab[2]);
                $sexe = trim($tab[3]);
                $date_naissance = trim($tab[4]);
                $city = trim($tab[5]);
                $poids = trim($tab[6]);
                $taille = trim($tab[7]);
                $sport = trim($tab[8]);
                $sports_pratiques = trim($tab[9]);
                $description = trim($tab[10]);
                $adresse = trim($tab[11]);
                $image = trim($tab[12]);
                $date_inscription = trim($tab[13]);
                $abonnement = trim($tab[14]);

                $profilTrouve = true;
                break; // Sortir de la boucle une fois que les informations sont trouvées
            }
        }
    }
    fclose($handle);
}

if (!$profilTrouve) {
    echo "Profil non trouvé.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="profil.css">
    <link rel="stylesheet" href="modificationprofil.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap">
    <title>Profil</title>
</head>
<body>      

<div class="banner">
    <h1><a href="../visiteur/acceuil.php">SportMeet </a></h1>
    <p><em>Rencontrez l'âme sœur sur la piste de votre passion !</em></p>
    <button onclick="window.location.href='abonnements.html'">Abonnements</button>
</div>
<div id="page">
    <h1><u>Profil</u></h1>
    <h2>Informations personnelles :</h2>

    <form action="traitementmodif.php" method="post" enctype="multipart/form-data">
        <img src="../uploads/<?php echo htmlspecialchars($image); ?>" alt="pas" width="100" height="100"/><br>
        <input type="hidden" id="photo" name="photo" value="<?php echo htmlspecialchars($image); ?>">

        <label> Nom : </label>
        <input type="text" id="nom" name="nom" required value="<?php echo htmlspecialchars($nom); ?>"><br>

        <p> Pseudo : <?php echo htmlspecialchars($pseudo); ?> </p>
        <input type="text" id="pseudo" name="id" value="<?php echo htmlspecialchars($pseudo); ?>" style="display: none;">

        <p> Mot de passe :
        <input type="text" id="password" name="mdp" value="<?php echo htmlspecialchars($mdp); ?>">
        </p>

        <label for="adresse">Adresse complète :</label>
        <input type="text" id="adresse" name="adresse" required value="<?php echo htmlspecialchars($adresse); ?>"><br>

        <label>Sexe :</label>
        <input type="radio" name="sexe" value="homme" <?php if ($sexe === "homme") echo "checked"; ?> required> Homme
        <input type="radio" name="sexe" value="femme" <?php if ($sexe === "femme") echo "checked"; ?>> Femme
        <input type="radio" name="sexe" value="autre" <?php if ($sexe === "autre") echo "checked"; ?>> Autre<br>

        <label for="">Date de naissance : </label>
        <input type="date" id="date_naissance" name="date_naissance" value="<?php echo htmlspecialchars($date_naissance); ?>" readonly><br>

        <label>Lieu de résidence :</label>
        <select name="city" id="city">
            <option value="France" <?php if ($city === "France") echo "selected"; ?>>France</option>
            <option value="Autre" <?php if ($city === "Autre") echo "selected"; ?>>Autre</option>
        </select><br>

        <label for="poids">Poids : </label>
        <input type="number" id="poids" name="poids" value="<?php echo htmlspecialchars($poids); ?>" readonly><br>

        <label for="taille">Taille : </label>
        <input type="number" id="taille" name="taille" value="<?php echo htmlspecialchars($taille); ?>" readonly><br>

        <label>Sport : </label>
        <select name="sport">
            <option value="pratique occasionnelle" <?php if ($sport === "pratique occasionnelle") echo "selected"; ?>>Pratique occasionnelle</option>
            <option value="souvent" <?php if ($sport === "souvent") echo "selected"; ?>>Souvent</option>
            <option value="Tous les jours" <?php if ($sport === "Tous les jours") echo "selected"; ?>>Tous les jours</option>
            <option value="Accro au sport" <?php if ($sport === "Accro au sport") echo "selected"; ?>>Accro au sport</option>
        </select><br>

        <label>Sport(s) pratiqué(s) :</label>
        <input type="text" name="sports_pratiques" required value="<?php echo htmlspecialchars($sports_pratiques); ?>"><br>

        <label for="description">Description :</label><br>
        <textarea id="description" name="description" rows="4" cols="50"><?php echo htmlspecialchars($description); ?></textarea><br><br>
        <input type="submit" value="Soumettre">

        <input type="hidden" name="date_inscription" value="<?php echo htmlspecialchars($date_inscription); ?>">
        <input type="hidden" name="abonnement" value="<?php echo htmlspecialchars($abonnement); ?>">
    </form>
</div>
</body>
</html>
