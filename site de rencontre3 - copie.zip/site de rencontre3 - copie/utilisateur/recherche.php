<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="recherche.css">
</head>
<body>
    <div>
      
        <form method="post" id="page">
        <a href="../visiteur/acceuil.php">SportMeet </a>
            <br>
            Recherche: <input type="text" name="recherche">
            <br>
            <br>
            <label>Lieu de résidence :</label>
    <select name="city" id="city">
    <option value="...">...</option>
        <option value="France">France</option>
        <option value="Autre">Autre</option>
    </select>
  
    <label> Genre : </label>
    <select name="genre" id="genre">
    <option value="...">...</option>
        <option value="homme"> Homme </option>
        <option value="femme"> Femme </option>
    </select>
   
    <label> Abonné : </label>
    <select name="abonne" id="abonne">
    <option value="...">...</option>
    <option value="2">Admin</option>
        <option value="1">Abonné</option>
        <option value="0">Non-Abonné</option>
    </select>

    <label> Fréquence de pratique sportive : </label>
    <select  name="sport">
    <option value="...">...</option>
        <option value="pratique occasionnelle">Pratique occasionnelle</option>
        <option value="souvent">Souvent</option>
        <option value="Tous les jours">Tous les jours</option>
        <option value="Acrro au sport">Accro au sport</option>
    </select>
    <br> <br>
    <button type="submit" id="search">Rechercher</button>
    
    <br><br>
        </form>
    </div><?php
$v = 0;
if (isset($_POST["recherche"]) || isset($_POST["abonne"]) || isset($_POST["genre"]) || isset($_POST['sport']) || isset($_POST["city"])) {
    // Initialiser les variables de recherche
    $recherche = isset($_POST["recherche"]) ? $_POST["recherche"] : "";
    $abonne = isset($_POST["abonne"]) ? $_POST["abonne"] : "";
    $genre = isset($_POST["genre"]) ? $_POST["genre"] : "";
    $sport = isset($_POST['sport']) ? $_POST['sport'] : "";
    $city = isset($_POST['city']) ? $_POST['city'] : "";


    // Chemin vers le fichier de données
    $fichier = "../donnees.txt";

    if (file_exists($fichier)) {
        $handle = fopen($fichier, "r");
        
        if ($handle) {
            while (($donnee = fgets($handle)) !== false) {
                $tab = explode("_", $donnee);
                
                // Vérifier si la recherche correspond à l'une des valeurs jusqu'à tab[16]
                if (in_array($recherche, array_slice($tab, 0, 10)) ||
                    in_array($abonne, array_slice($tab, 0, 17)) ||
                    in_array($genre, array_slice($tab, 0, 17)) ||
                    in_array($sport, array_slice($tab, 0, 17)) ||
                    in_array($city, array_slice($tab, 0, 17))) {
                    echo '<br>';
                    echo '<table border="3" class="clickableTable">';
                    echo '<tr>';
                    echo '<td><img src="../uploads/' . $tab[12] . '" width="100" height="100"></td>';
                    echo '</tr>';
                    echo '<tr><td>id : ' . $tab[0] . '</td></tr>';
                    echo '<tr><td>Sport(s) pratiqué(s) : ' . $tab[10] . '</td></tr>';
                    echo '</table>';
                    echo "<br>";
                    $v = 1;
                }
            }
            if ($v == 0) {
                echo "Aucun profil ne correspond à votre recherche";
            }
            fclose($handle);
        } else {
            echo "Erreur lors de l'ouverture du fichier.";
        }
    } else {
        echo "Le fichier n'existe pas.";
    }
}
?>

    <script>
    // Ajouter un gestionnaire d'événements pour rediriger vers le profil lors du clic sur la table
    var tables = document.querySelectorAll('.clickableTable');
    tables.forEach(function(table) {
        table.addEventListener('click', function() {
            var id = this.querySelector('tr:nth-child(2) td').innerText.split(':')[1].trim();
            window.location.href = "profil2.php?id=" + id;
        });
    });
</script>
</body>
</html>
