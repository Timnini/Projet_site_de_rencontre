<?php
$pseudo = $_GET['id'];

$fichier = "../donnees.txt";
$handle = fopen($fichier, "r");
$currentDate = date('Y-m-d');

if ($handle) {
    while (($donnee = fgets($handle)) !== false) {
        $tab = explode("_", trim($donnee)); // Utiliser trim() pour supprimer les espaces et les nouvelles lignes
        
        if (count($tab) < 15) {
            continue; // Sauter les lignes invalides
        }

        $id = $tab[0];
        $mdp = $tab[1];

        if ($pseudo === $id) {
            // Identifiant et mot de passe trouvés, extrayez les informations associées
            $nom = $tab[2];
            $sexe = $tab[3];
            $date_naissance = $tab[4];
            $city = $tab[5];
            $poids = $tab[6];
            $taille = $tab[7];
            $sport = $tab[8];
            $sports_pratiques = $tab[9];
            $description = $tab[10];
            $adresse = $tab[11];
            $image = $tab[12];
            $date_inscription = $tab[13];
            $abonnement = $tab[14];
            $date_expiration = isset($tab[15]) ? $tab[15] : '';

            if ($abonnement >= 1) {
                $pseudo_visite = array();
                for ($i = 16; $i < count($tab); $i++) {
                    array_push($pseudo_visite, $tab[$i]);
                }
            }
            break; // Sortir de la boucle une fois que les informations sont trouvées
        }
    }
    fclose($handle);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="profil.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap">
    <title>Profil</title>
</head>
<body>      

<div id="page">
<div class="banner">
    <h1><a href="../visiteur/acceuil.php">SportMeet </a></h1>
    <p><em> Slogan </em></p>
    <form action="../admin/supprimer_profil.php" enctype="multipart/form-data" method="post">
    <input type="hidden" name="pseudo" value="<?php echo htmlspecialchars($pseudo); ?>">
    <button type="submit" onclick="return confirm('Voulez-vous vraiment supprimer ce profil ?')">Suppression</button>
</form>
<form action="../admin/banissement_profil.php" enctype="multipart/form-data" method="post">
    <input type="hidden" name="pseudo" value="<?php echo htmlspecialchars($pseudo); ?>">
    <button type="submit" onclick="return confirm('Voulez-vous vraiment supprimer ce profil ?')"> Banir </button>
</form>
</div>

<h1 id="profil"><u>Profil</u></h1>
<h2>Informations personnelles :</h2>

<img src="../uploads/<?php echo htmlspecialchars($image); ?>" alt="default.jpg" width="100" height="100"/>
<?php if ($abonnement >= 1 && $currentDate < $date_expiration) { ?>
    <p> Abonné </p>
<?php } ?>

<p> Nom : <?php echo htmlspecialchars($nom); ?> </p>
<p> Pseudo : <?php echo htmlspecialchars($pseudo); ?></p>
<p> Mot de passe : <?php echo htmlspecialchars($mdp); ?>
<p> Date d'inscription : <?php echo htmlspecialchars($date_inscription); ?></p>
<p> Sexe : <?php echo htmlspecialchars($sexe); ?></p>
<p> Date de naissance : <?php echo htmlspecialchars($date_naissance); ?></p>
<p> Lieu de résidence : <?php echo htmlspecialchars($city); ?></p>
<p> Poids : <?php echo htmlspecialchars($poids); ?> kg</p>
<p> Taille : <?php echo htmlspecialchars($taille); ?> cm</p>
<p> Fréquence sport : <?php echo htmlspecialchars($sport); ?></p>
<p> Sport(s) pratiqué(s) : <?php echo htmlspecialchars($sports_pratiques); ?></p>
<p> Description : <?php echo htmlspecialchars($description); ?></p>

<?php if (isset($pseudo_visite)) { ?>
    <div>Personnes ayant visité le profil : <?php echo htmlspecialchars(implode(" ", $pseudo_visite)); ?></div>
<?php } ?>

<form action="modificationprofil.php" enctype="multipart/form-data" method="post"> 
    <br>
    <button type="submit"> Modifier </button>
</form>

<form action="../abonnement/mesmessages.php" enctype="multipart/form-data" method="post"> 
    <br>
    <button type="submit"> Mes messages </button>
</form>
</div>
</body>
</html>
