<?php
session_start();

if (!isset($_SESSION['pseudo'])) {
    header("Location: ../visiteur/connexion.html"); // Redirige vers la page de connexion si l'utilisateur n'est pas connecté
    exit();
}

$pseudo = $_SESSION['pseudo'];
$fichier = "../donnees.txt";
$handle = fopen($fichier, "r");
$currentDate = date('Y-m-d');

// Initialiser les variables pour éviter les erreurs non définies
$mdp = $nom = $sexe = $date_naissance = $city = $poids = $taille = $sport = $sports_pratiques = $description = $adresse = $image = $date_inscription = $abonnement = $date_expiration = "";
$pseudo_visite = [];

if ($handle) {
    while (($donnee = fgets($handle)) !== false) {
        $tab = explode("_", $donnee);
        $id = $tab[0];

        if ($pseudo == $id) {
            // Identifiant et mot de passe trouvés, extrayez les informations associées
            $mdp = $tab[1];
            $nom = $tab[2];
            $sexe = $tab[3];
            $date_naissance = $tab[4];
            $city = $tab[5];
            $poids = $tab[6];
            $taille = $tab[7];
            $sport = $tab[8];
            $sports_pratiques = $tab[9];
            $description = $tab[10];
            $adresse = $tab[11];
            $image = $tab[12];
            $date_inscription = $tab[13];
            $abonnement = $tab[14];
            if(isset($tab[15])){
            $date_expiration = $tab[15];}

            if ($abonnement >= 1) {
                $i = 16;
                while (isset($tab[$i])) {
                    $pseudo_visite[] = $tab[$i];
                    $i++;
                }
            }
            break; // On arrête la boucle une fois que l'utilisateur est trouvé
        }
    }
    fclose($handle);
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="profil.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap">
    <title>Profil</title>
</head>
<body>      

<div class="banner">
    <h1><a href="../visiteur/acceuil.php">SportMeet</a></h1>
    <button onclick="window.location.href='../abonnement/abonnements.html'">Abonnements</button>
</div>

<div id="page">
    <h1 id="profil"><u>Profil</u></h1>
    <h2>Informations personnelles :</h2>

    <img src="../uploads/<?php echo $image; ?>" alt="Image non disponible" width="100" height="100"/>

    <?php if ($abonnement >= 1 && $currentDate < $date_expiration) { ?>
        <p>Abonné</p>
    <?php } ?>

    <p>Nom : <?php echo $nom; ?></p>
    <p>Pseudo : <?php echo $pseudo; ?></p>
    <p>Mot de passe : <?php echo $mdp; ?></p>
    <p>Date d'inscription : <?php echo $date_inscription; ?></p>
    <p>Sexe : <?php echo $sexe; ?></p>
    <p>Date de naissance : <?php echo $date_naissance; ?></p>
    <p>Lieu de résidence : <?php echo $city; ?></p>
    <p>Poids : <?php echo $poids; ?> kg</p>
    <p>Taille : <?php echo $taille; ?> cm</p>
    <p>Fréquence sport : <?php echo $sport; ?></p>
    <p>Sport(s) pratiqué(s) : <?php echo $sports_pratiques; ?></p>
    <p>Description : <?php echo $description; ?></p>

    <?php if (!empty($pseudo_visite)) { ?>
        <div>Personnes ayant visité votre profil : <?php echo implode(" ", $pseudo_visite); ?></div>
    <?php } ?>

    <form action="modificationprofil.php" method="post" style="float:right"> 
        <button type="submit">Modifier ✏️</button>
    </form>

    <form action="../abonnement/mesmessages.php" method="post" style="float:right"> 
        <button type="submit">Mes messages 💬</button>
    </form>

    <?php if ($abonnement == 2) { ?>
        <br>
        <button onclick="location.href='../admin/admin.html'">Gestion Admin</button>
        <br><br>
    <?php } ?>

</div>
</body>
</html>
