<?php
// Vérifier si un message est soumis
if (isset($_POST["message"]) && !empty($_POST["message"])) {
    // Ajouter le message au fichier texte
    $file = fopen("messages.txt", "a");
    fwrite($file, "self|" . $_POST["message"] . "\n");
    fclose($file);
}

// Redirection vers message.php avec l'ID comme paramètre GET
header("Location: message.php?id=" . $_POST['id']);
exit;
?>
