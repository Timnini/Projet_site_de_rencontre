<?php

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $pseudo = $_POST["pseudo"];
    $password = $_POST["password"];

    $fichier = "donnees.txt";
    $handle = fopen($fichier, "r+");

    if ($handle) {
        while (!feof($handle)) { 
            $id = trim(fgets($handle)); 
            $mdp = trim(fgets($handle)); 
            if ($pseudo == $id && $password == $mdp) {

                $nom = $_POST["nom"];
                $sexe = $_POST["sexe"];
                $photo = $_POST["photo"];
                $date_naissance = $_POST["date_naissance"];
                $city = $_POST["city"];
                $poids = $_POST["poids"];
                $taille = $_POST["taille"];
                $sport = $_POST["sport"];
                $sports_pratiques = $_POST["sports_pratiques"];
                $description = $_POST["description"];
                $adresse = $_POST["adresse"];
                if ($handle) {
                    // Écriture des données dans le fichier texte
                    fwrite($handle,$nom . PHP_EOL);
                    fwrite($handle,$sexe . PHP_EOL);
                    fwrite($handle,$date_naissance . PHP_EOL);
                    fwrite($handle,$city . PHP_EOL);
                    fwrite($handle,$poids . PHP_EOL);
                    fwrite($handle,$taille . PHP_EOL);
                    fwrite($handle, $sport. PHP_EOL);
                    fwrite($handle,$sports_pratiques . PHP_EOL);
                    fwrite($handle,$description . PHP_EOL);
                    fwrite($handle,$adresse . PHP_EOL);
                    fwrite($handle, $photo . PHP_EOL); // Réécrire le nom de la photo
                    fgets($handle); // Ignorer la ligne de date d'inscription
                    fgets($handle); // Ignorer la ligne de date d'inscription
                    fclose($handle);
                    echo "Les données ont été enregistrées avec succès. <a href='acceuil.php'>Retour à la page d'accueil</a>";
                } 
                else {
                    echo "Erreur lors de l'ouverture du fichier.";
                }
                // Redirige vers la page de profil
                exit();
            } else {
                for($i=0;$i<45;$i++){ // On passe à la prochaine entrée utilisateur
                    fgets($handle);
                }
            }
        }
        fclose($handle);
        echo "Mot de passe ou identifiant incorrect";
    } else {
        echo "Erreur lors de l'ouverture du fichier";
    }
}
?>
