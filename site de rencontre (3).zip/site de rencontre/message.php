<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interface de messagerie</title>
    <style>
        /* Styles CSS précédents */
    </style>
</head>
<body>
    <div class="container">
        <ul class="messages">
        <?php
session_start();

// Vérifier si l'ID est transmis via GET
if(isset($_POST['id'])) {
    // Noms des participants
    $participant1 = $_SESSION['pseudo'];
    $participant2 = $_POST['id'];
    

        // Nom du fichier de messages
    $nom_fichier = $participant1 . "_" . $participant2 . ".txt";

    // Chemin vers le dossier de stockage des fichiers de messages
    $dossier_messages = "messages/";

    // Créer le fichier de messages s'il n'existe pas déjà
    if (!file_exists($dossier_messages . $nom_fichier)) {
        $fichier = fopen($dossier_messages . $nom_fichier, "w");
        fclose($fichier);
        echo "Le fichier de messages a été créé avec succès : " . $nom_fichier;
    } else {
        echo "Le fichier de messages existe déjà : " . $nom_fichier;
    }

    // Récupérer les messages depuis le fichier texte
    $messages = file_get_contents($dossier_messages . $nom_fichier);
    $messages = explode("\n", $messages);

    foreach ($messages as $message) {
        $message_data = explode("|", $message);
        $class = ($message_data[0] == "self") ? "self" : "other";
        echo '<li class="message ' . $class . '">' . $message_data[1] . '</li>';
    }
} else {
    echo "Aucun ID de conversation transmis.";
}
?>

        </ul>
        <div class="message">
            <form method="post" action="send_message.php">
            <input type="hidden" name="id" value="<?php echo $participant2; ?>">
                <input type="text" name="message" placeholder="Entrez votre message...">
                <button type="submit">Envoyer</button>
            </form>
        </div>
    </div>
</body>
</html>
