<?php
session_start();

$id = $_POST['id'];

// Vérifier si un message est soumis
if (isset($_POST["message"]) && !empty($_POST["message"])) {
    // Ajouter le message au fichier texte
    $nom_fichier = $_SESSION['nom_fichier'];
    $file = fopen("../messages/$nom_fichier", "a");
    fwrite($file, "|" . "[" . $_SESSION['pseudo'] . "]" . " : " . $_POST["message"]);
    fclose($file);
}

// Vérifier si la variable POST 'idmessupp' est définie
if (isset($_POST['idmessupp']) && $_POST['idmessupp'] != false) {
    // Récupérer l'identifiant de la ligne à supprimer
    $lineId = intval($_POST['idmessupp']) - 1;

    // Chemin du fichier de messages
    $nom_fichier = $_SESSION['nom_fichier'];
    $fichierMessages = "../messages/$nom_fichier";

    // Lire le contenu du fichier dans un tableau
    $contenu = file_get_contents($fichierMessages);

    // Diviser le contenu en messages individuels
    $messages = explode("|", $contenu);

    if (isset($messages[$lineId])) {
        unset($messages[$lineId]);

        // Réécrire le contenu du fichier avec les messages mis à jour
        $nouveauContenu = implode("|", $messages);
        file_put_contents($fichierMessages, $nouveauContenu);
    }
}


if (isset($_POST['ligne_signaler']) && $_POST['ligne_signaler'] != false) {
    // Récupérer l'identifiant de la ligne à supprimer
    $lineId = intval($_POST['ligne_signaler']) - 1;

    // Chemin du fichier de messages
    $nom_fichier = $_SESSION['nom_fichier'];
    $fichierMessages = "messages/$nom_fichier";

    // Lire le contenu du fichier dans un tableau
    $contenu = file_get_contents($fichierMessages);

    // Diviser le contenu en messages individuels
    $messages = explode("|", $contenu);

    if (isset($messages[$lineId])) {
        $messages[$lineId] = $messages[$lineId] . " / signalé /";
        $fichier = "../abonnement/signalement.txt";
        $handle = fopen($fichier, "a");
        fwrite($handle,$messages[$lineId] . "|");
        // Réécrire le contenu du fichier avec les messages mis à jour
        $nouveauContenu = implode("|", $messages);
        file_put_contents($fichierMessages, $nouveauContenu);
    }
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirection</title>
</head>
<body>
    <form id="redirectForm" action="message.php" method="post">
        <!-- Champ de formulaire caché pour stocker la valeur de $id -->
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
    </form>
    <script>
        // Soumettre automatiquement le formulaire
        document.getElementById('redirectForm').submit();
    </script>
</body>
</html>
