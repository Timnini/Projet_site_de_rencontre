<?php
session_start();

// Vérifiez que l'utilisateur est connecté
if (!isset($_SESSION['pseudo'])) {
    // Redirigez l'utilisateur vers la page de connexion s'il n'est pas connecté
    header("location: ../visiteur/connexion.html");
    exit();
}

// Validez l'entrée de l'ID
if (isset($_POST['id']) && !empty($_POST['id'])) {
    $pseudo = $_SESSION['pseudo'];
    $idBloque = $_POST['id'];

    // Ouvrir le fichier en mode ajout
    $fichier = fopen("utilisateurs_bloque.txt", "a");

    if ($fichier) {
        // Écrire les données avec un séparateur pour une lecture plus facile
        fwrite($fichier, $pseudo . "_" . $idBloque . "\n");
        fwrite($fichier, $idBloque . "_" . $pseudo . "\n");
        fclose($fichier);

        // Redirigez l'utilisateur vers la page d'accueil
        header("location: ../visiteur/acceuil.php");
        exit();
    } else {
        // Gérer l'erreur si le fichier ne peut pas être ouvert
        echo "Erreur : Impossible d'ouvrir le fichier.";
    }
} else {
    // Gérer l'erreur si l'ID n'est pas défini ou est vide
    echo "Erreur : ID d'utilisateur non valide.";
}
?>
