<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mesmessage.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap">
    <title>SportMeet - Messages</title>
</head>
<body>

<div class="banner">
    <h1><a href="../visiteur/acceuil.php">SportMeet</a></h1>
    <p><em>Rencontrez vos partenaires d'entraînement et défiez vos limites ensemble !</em></p>
</div>

<div class="container">
    <div class="centered-element">

        <!-- Add some spacing -->
        <br><br><br><br><br><br>

        <?php 

        $pseudo = $_GET['id'];

        // Directory containing message files
        $dossier = "../messages/";

        // Get the list of files in the directory
        $fichiers = scandir($dossier);

        // Loop through the files and process each one
        foreach ($fichiers as $fichier) {
            if ($fichier !== '.' && $fichier !== '..') {
                // Split the filename to get the user parts
                $parties = explode('_', $fichier);
                $partie1 = $parties[0];
                $partie2 = explode('.', $parties[1])[0];

                // Determine if the current user is part of the discussion
                if ($partie1 == $pseudo) {
                    $id = $partie2;
                } elseif ($partie2 == $pseudo) {
                    $id = $partie1;
                } else {
                    continue;
                }

                // Open and read the data file for user information
                $fichierData = "../donnees.txt";
                $handle = fopen($fichierData, "r");

                if ($handle) {
                    while (($line = fgets($handle)) !== false) {
                        $tab = explode("_", $line);
                        $id2 = $tab[0];
                        if ($id == $id2) {
                            $image = $tab[12];
                            break;
                        }
                    }
                    fclose($handle);
                }

                // Output the discussion item
                echo '<form action="message2.php" method="post">';
                echo "<div class='discussion-item'>";
                echo "<div class='discussion-item-text'>";
                echo "<img src='../$image' alt='User Image'  width='50' height='50'>";
                echo "<style> img{
                    border-radius: 50%;  
                    margin-left: 7%;
                }
                </style>";
                echo htmlspecialchars($id); // Secure the output
                echo "</div>";
                echo "<div class='discussion-item-button'>";
                echo '<input type="hidden" name="id" value="' . htmlspecialchars($id) . '">';
                echo '<input type="hidden" name="pseudo" value="' . htmlspecialchars($pseudo) . '">';
                echo '<button type="submit">✉️</button>';
                echo "</div></div></form>";
                echo "<br>";
            }
        }
        ?>

    </div>
</div>

</body>
</html>
