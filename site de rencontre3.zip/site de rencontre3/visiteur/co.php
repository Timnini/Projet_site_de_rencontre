<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pseudo = $_POST["pseudo"];
    $password = $_POST["password"];

    // Fichier contenant les données des utilisateurs
    $fichier = "../donnees.txt";

    // Vérifie si le fichier peut être ouvert
    if (is_readable($fichier)) {
        $handle = fopen($fichier, "r");

        // Vérifie l'ouverture du fichier
        if ($handle) {
            $found = false; // Indicateur si l'utilisateur est trouvé

            // Parcourt le fichier ligne par ligne
            while (($donnee = fgets($handle)) !== false) {
                $tab = explode("_", $donnee);
                $id = $tab[0];
                $mdp = trim($tab[1]); // Utilisation de trim() pour enlever les espaces blancs

                // Vérifie les identifiants
                if ($pseudo == $id && $password == $mdp) {
                    $_SESSION['connexion_pseudo'] = true;
                    $_SESSION['pseudo'] = $pseudo;
                    header("Location: acceuil.php"); // Redirige vers la page d'accueil
                    fclose($handle);
                    exit();
                }
            }

            fclose($handle);

            // Si les identifiants ne sont pas trouvés
            if (!$found) {
                echo "Mot de passe ou identifiant incorrect";
            }
        } else {
            echo "Erreur lors de l'ouverture du fichier";
        }
    } else {
        echo "Le fichier des données utilisateur est introuvable ou inaccessible";
    }
}
?>
