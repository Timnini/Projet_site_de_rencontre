<?php

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $pseudo = $_POST["pseudo"];
    $password = $_POST["password"];

    $fichier = "donnees.txt";
    $handle = fopen($fichier, "r");

    if ($handle) {
        while (!feof($handle)) { 
            $id = trim(fgets($handle)); 
            $mdp = trim(fgets($handle)); 
            if ($pseudo == $id && $password == $mdp) {
                fclose($handle);
                $_SESSION['pseudo'] = $pseudo;
                $_SESSION['password'] = $password; // Stocke le pseudo dans la session
                header("Location: profil.php"); // Redirige vers la page de profil
                exit();
            } else {
                for($i=0;$i<13;$i++){ // On passe à la prochaine entrée utilisateur
                    fgets($handle);
                }
            }
        }
        fclose($handle);
        echo "Mot de passe ou identifiant incorrect";
    } else {
        echo "Erreur lors de l'ouverture du fichier";
    }
}
?>
