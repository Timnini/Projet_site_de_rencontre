<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="acceuil.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap">
    <title>Accueil</title>
</head>

<body>

<div class="banner">
<h1><a href="acceuil.php">SportMeet </a></h1>
    <p><em> Slogan </em></p>
    <div class="button-bandeau">
        <button onclick="window.location.href='connexion.html'">connexion</button>
    </div>
</div>

<?php 

$fichier = "donnees.txt";
$handle = fopen($fichier, "r");

$id = trim(fgets($handle));
for($j=0;$j<8;$j++){
    $rien = trim(fgets($handle));
}
$sport_pratique = trim(fgets($handle));
for($j=0;$j<2;$j++){
    $rien = trim(fgets($handle));
}
$image = trim(fgets($handle));

for($j=0;$j<2;$j++){
    $rien = trim(fgets($handle));
}
?>
<br>


<style>
    /* Définir le curseur pointer pour la table */
    #clickableTable {
        cursor: pointer;
    }
</style>

<table border="3" id="clickableTable">
<tr>
  
<td><img src="<?php echo $image;?>"></td></tr>

<tr><td> id : <?php echo $id?> </td></tr>

<tr><td> Sport(s) pratiqué(s) : <?php echo $sport_pratique?> </td></tr>
</table>


<script>
    function redirectTo() {
        window.location.href = "profil.php";
    }

    document.getElementById("clickableTable").onclick = function() {
        redirectTo();
    };
</script>

<?php
$id = trim(fgets($handle));
for($j=0;$j<8;$j++){
    $rien = trim(fgets($handle));
}
$sport_pratique = trim(fgets($handle));
for($j=0;$j<2;$j++){
    $rien = trim(fgets($handle));
}
$image = trim(fgets($handle));

for($j=0;$j<2;$j++){
    $rien = trim(fgets($handle));
}
?>

<br>

<table border="3">
<tr>
  
<td><img src="<?php echo $image;?>" width="100" height="100"></td></tr>

<tr><td> id : <?php echo $id?> </td></tr>

<tr><td> Sport(s) pratiqué(s) : <?php echo $sport_pratique?> </td></tr>
</table>




</body>
</html>
